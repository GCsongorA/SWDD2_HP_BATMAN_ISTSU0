﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SWDD2_HP_BATMAN_ISTSU0
{
    internal class InvalidItemTypeException:Exception
    {
        public InvalidItemTypeException()
        {
            
        }
    }
}
