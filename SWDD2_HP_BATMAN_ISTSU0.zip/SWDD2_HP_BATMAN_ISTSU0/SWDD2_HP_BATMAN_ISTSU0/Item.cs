﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISTSU0_SwDD2_HP_Batman
{
    internal interface Item
    {
        int Cost { get; }
        int UtilityValue { get; }
    }
}
