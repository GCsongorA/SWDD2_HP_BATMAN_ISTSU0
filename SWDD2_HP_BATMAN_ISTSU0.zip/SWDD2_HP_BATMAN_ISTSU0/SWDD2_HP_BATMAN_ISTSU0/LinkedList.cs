﻿using ISTSU0_SwDD2_HP_Batman;
using System;
using System.Collections.Generic;
using System.Text;

namespace SwDD2_LinkedLists
{
    class LinkedList<T> where T : Item
    {
        class ListElement
        {
            public T data;
            public ListElement next;
        }

        ListElement head;

        public void Add(T data)
        {
            ListElement newElement = new ListElement();
            newElement.data = data;
            if (head == null)   // the list is empty
            {
                head = newElement;
            }
            else    // list has some elements in it
            {
                ListElement p = head;
                while (p.next != null)
                {
                    p = p.next;
                }
                p.next = newElement;
            }
        }

        public void Remove(T data)
        {
            ListElement p = head;
            ListElement e = null;
            while (p != null && !p.data.Equals(data))
            {
                e = p;
                p = p.next;
            }
            if (p != null)
            {
                if (e == null)
                {
                    head = p.next;
                }
                else
                {
                    e.next = p.next;
                    // FREE(p)
                }
            }
            else
            {
                throw new Exception("Data is not in the list.");
                //keeps throwing this fucking shit for no reason
            }
        }


        public void Traverse()
        {
            ListElement p = head;
            while (p.next != null)
            {
                switch (p.data)
                {
                    case Batarang:
                        Console.WriteLine("Batarang"+ " " + p.data.Cost+" "+p.data.UtilityValue);
                        break;
                    case Batcopter:
                        Console.WriteLine("Batcopter" + " " + p.data.Cost + " " + p.data.UtilityValue);
                        break;
                    case Batmobil:
                        Console.WriteLine("Batmobil" + " " + p.data.Cost + " " + p.data.UtilityValue);
                        break;
                    case ExplosiveGel:
                        Console.WriteLine("Explosivegel" + " " + p.data.Cost + " " + p.data.UtilityValue);
                        break;
                    case Parachute:
                        Console.WriteLine("Parachute" + " " + p.data.Cost + " " + p.data.UtilityValue);
                        break;
                    default:
                        Console.WriteLine("asd");
                        break;
                }
                p = p.next;
            }
            switch (p.data)
            {
                case Batarang:
                    Console.WriteLine("Batarang" +" "+ p.data.Cost + " " + p.data.UtilityValue);
                    break;
                case Batcopter:
                    Console.WriteLine("Batcopter" + " " + p.data.Cost + " " + p.data.UtilityValue);
                    break;
                case Batmobil:
                    Console.WriteLine("Batmobil" + " " + p.data.Cost + " " + p.data.UtilityValue);
                    break;
                case ExplosiveGel:
                    Console.WriteLine("Explosivegel" + " " + p.data.Cost + " " + p.data.UtilityValue);
                    break;
                case Parachute:
                    Console.WriteLine("Parachute" + " " + p.data.Cost + " " + p.data.UtilityValue);
                    break;
                default:
                    Console.WriteLine("asd");
                    break;
            }

        }
    }
}
